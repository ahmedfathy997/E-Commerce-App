﻿using ECommerceApp.Data;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class ViewOrdersForm : Form
    {
        public ViewOrdersForm()
        {
            InitializeComponent();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            OrderRepository orderRepository = new OrderRepository(new AppDbContext());
            ordersGridView.DataSource = orderRepository.GetAll();
        }

        private void ViewOrdersForm_Load(object sender, EventArgs e)
        {
            OrderRepository orderRepository = new OrderRepository(new AppDbContext());
            ordersGridView.DataSource = orderRepository.GetAll();

            orderRepository.OrderPlaced += OrderRepository_OrderPlaced;
        }

        private void OrderRepository_OrderPlaced(object source, EventArgs e)
        {
            // Refresh the DataGridView
            OrderRepository orderRepository = new OrderRepository(new AppDbContext());
            ordersGridView.DataSource = orderRepository.GetAll();
        }
    }
}
