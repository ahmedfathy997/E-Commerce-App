﻿using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class AddAdminForm : Form
    {
        public Admin NewAdmin { get; set; }
        public AddAdminForm()
        {
            InitializeComponent();
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Get the entered username and password
            string username = txtFullName.Text;
            string password = txtPassword.Text;
            string email = txtEmail.Text;
            string jobTitle = txtJobTitle.Text;

            // Create a new admin
            Admin admin = new Admin
            {
                FullName = username,
                Password = password,
                Email = email,
                JobTitle = jobTitle,
            };

            // Add the new admin to the database
            UserRepository userRepository = new UserRepository(new AppDbContext());
            userRepository.Add(admin);

            // Save changes to the database
            userRepository.Save();

            // Clear the input fields
            txtFullName.Clear();
            txtPassword.Clear();
            txtEmail.Clear();
            txtJobTitle.Clear();

            // Display a success message
            MessageBox.Show("Admin added successfully.");
        }
    }
}
