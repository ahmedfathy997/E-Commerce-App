﻿using ECommerceApp.Models;

namespace ECommerceApp
{
    public partial class EditCategoryForm : Form
    {
        public EditCategoryForm(Category selectedCategory)
        {
            InitializeComponent();
        }

        public Category UpdatedCategory { get; set; }
    }
}
