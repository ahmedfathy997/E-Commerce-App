﻿namespace ECommerceApp
{
    partial class EditProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnEdit = new Button();
            txtJobTitle = new TextBox();
            txtActive = new TextBox();
            txtPassword = new TextBox();
            txtEmail = new TextBox();
            txtFullName = new TextBox();
            txtID = new TextBox();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            SuspendLayout();
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(229, 203);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(97, 33);
            btnEdit.TabIndex = 57;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = true;
            // 
            // txtJobTitle
            // 
            txtJobTitle.Location = new Point(101, 171);
            txtJobTitle.Name = "txtJobTitle";
            txtJobTitle.Size = new Size(129, 23);
            txtJobTitle.TabIndex = 56;
            // 
            // txtActive
            // 
            txtActive.Location = new Point(101, 142);
            txtActive.Name = "txtActive";
            txtActive.Size = new Size(129, 23);
            txtActive.TabIndex = 55;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(101, 114);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(129, 23);
            txtPassword.TabIndex = 54;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(101, 84);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(129, 23);
            txtEmail.TabIndex = 53;
            // 
            // txtFullName
            // 
            txtFullName.Location = new Point(101, 55);
            txtFullName.Name = "txtFullName";
            txtFullName.Size = new Size(129, 23);
            txtFullName.TabIndex = 52;
            // 
            // txtID
            // 
            txtID.Location = new Point(101, 26);
            txtID.Name = "txtID";
            txtID.Size = new Size(129, 23);
            txtID.TabIndex = 51;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(13, 171);
            label9.Name = "label9";
            label9.Size = new Size(66, 15);
            label9.TabIndex = 50;
            label9.Text = "CategoryID";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(13, 142);
            label10.Name = "label10";
            label10.Size = new Size(82, 15);
            label10.TabIndex = 49;
            label10.Text = "StockQuantity";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(13, 114);
            label11.Name = "label11";
            label11.Size = new Size(58, 15);
            label11.TabIndex = 48;
            label11.Text = "Unit Price";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(13, 87);
            label12.Name = "label12";
            label12.Size = new Size(62, 15);
            label12.TabIndex = 47;
            label12.Text = "Name(AR)";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(13, 59);
            label13.Name = "label13";
            label13.Size = new Size(62, 15);
            label13.TabIndex = 46;
            label13.Text = "Name(EN)";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(15, 34);
            label14.Name = "label14";
            label14.Size = new Size(18, 15);
            label14.TabIndex = 45;
            label14.Text = "ID";
            // 
            // EditProductForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(346, 244);
            Controls.Add(btnEdit);
            Controls.Add(txtJobTitle);
            Controls.Add(txtActive);
            Controls.Add(txtPassword);
            Controls.Add(txtEmail);
            Controls.Add(txtFullName);
            Controls.Add(txtID);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label14);
            Name = "EditProductForm";
            Text = "Edit Product";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnEdit;
        private TextBox txtJobTitle;
        private TextBox txtActive;
        private TextBox txtPassword;
        private TextBox txtEmail;
        private TextBox txtFullName;
        private TextBox txtID;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
    }
}