﻿using ECommerceApp.Models;

namespace ECommerceApp
{
    public partial class EditAdminForm : Form
    {
        public Admin UpdatedAdmin { get; set; }
        public EditAdminForm(Admin selectedAdmin)
        {
            InitializeComponent();
        }
    }
}
