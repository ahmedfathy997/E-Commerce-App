﻿namespace ECommerceApp
{
    partial class AddCategoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAdd = new Button();
            txtName = new TextBox();
            txtID = new TextBox();
            label13 = new Label();
            label14 = new Label();
            SuspendLayout();
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(230, 70);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(97, 33);
            btnAdd.TabIndex = 57;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            // 
            // txtName
            // 
            txtName.Location = new Point(99, 41);
            txtName.Name = "txtName";
            txtName.Size = new Size(129, 23);
            txtName.TabIndex = 52;
            // 
            // txtID
            // 
            txtID.Location = new Point(99, 12);
            txtID.Name = "txtID";
            txtID.Size = new Size(129, 23);
            txtID.TabIndex = 51;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(11, 45);
            label13.Name = "label13";
            label13.Size = new Size(39, 15);
            label13.TabIndex = 46;
            label13.Text = "Name";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(13, 20);
            label14.Name = "label14";
            label14.Size = new Size(18, 15);
            label14.TabIndex = 45;
            label14.Text = "ID";
            // 
            // AddCategoryForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(339, 115);
            Controls.Add(btnAdd);
            Controls.Add(txtName);
            Controls.Add(txtID);
            Controls.Add(label13);
            Controls.Add(label14);
            Name = "AddCategoryForm";
            Text = "Add Category";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAdd;
        private TextBox txtName;
        private TextBox txtID;
        private Label label13;
        private Label label14;
    }
}