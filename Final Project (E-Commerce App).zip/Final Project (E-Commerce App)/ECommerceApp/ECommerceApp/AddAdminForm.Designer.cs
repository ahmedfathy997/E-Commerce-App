﻿namespace ECommerceApp
{
    partial class AddAdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtJobTitle = new TextBox();
            txtPassword = new TextBox();
            txtEmail = new TextBox();
            txtFullName = new TextBox();
            txtID = new TextBox();
            label9 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            btnAdd = new Button();
            SuspendLayout();
            // 
            // txtJobTitle
            // 
            txtJobTitle.Location = new Point(86, 153);
            txtJobTitle.Name = "txtJobTitle";
            txtJobTitle.Size = new Size(129, 23);
            txtJobTitle.TabIndex = 27;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(86, 124);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(129, 23);
            txtPassword.TabIndex = 25;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(86, 95);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(129, 23);
            txtEmail.TabIndex = 24;
            // 
            // txtFullName
            // 
            txtFullName.Location = new Point(86, 66);
            txtFullName.Name = "txtFullName";
            txtFullName.Size = new Size(129, 23);
            txtFullName.TabIndex = 23;
            // 
            // txtID
            // 
            txtID.Location = new Point(86, 37);
            txtID.Name = "txtID";
            txtID.Size = new Size(129, 23);
            txtID.TabIndex = 22;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(14, 153);
            label9.Name = "label9";
            label9.Size = new Size(50, 15);
            label9.TabIndex = 20;
            label9.Text = "Job Title";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(14, 125);
            label11.Name = "label11";
            label11.Size = new Size(57, 15);
            label11.TabIndex = 18;
            label11.Text = "Password";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(14, 98);
            label12.Name = "label12";
            label12.Size = new Size(36, 15);
            label12.TabIndex = 17;
            label12.Text = "Email";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(14, 70);
            label13.Name = "label13";
            label13.Size = new Size(61, 15);
            label13.TabIndex = 16;
            label13.Text = "Full Name";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(14, 40);
            label14.Name = "label14";
            label14.Size = new Size(18, 15);
            label14.TabIndex = 15;
            label14.Text = "ID";
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(236, 246);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(97, 33);
            btnAdd.TabIndex = 29;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            // 
            // AddAdminForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(345, 291);
            Controls.Add(btnAdd);
            Controls.Add(txtJobTitle);
            Controls.Add(txtPassword);
            Controls.Add(txtEmail);
            Controls.Add(txtFullName);
            Controls.Add(txtID);
            Controls.Add(label9);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label14);
            Name = "AddAdminForm";
            Text = "Add Admin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtJobTitle;
        private TextBox txtPassword;
        private TextBox txtEmail;
        private TextBox txtFullName;
        private TextBox txtID;
        private Label label9;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Button btnAdd;
    }
}