﻿namespace ECommerceApp.Models
{
    public class Customer : User
    {
        public string Phone { get; set; }
        public string Address { get; set; }
    }

}
