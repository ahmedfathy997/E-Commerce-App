﻿namespace ECommerceApp.Models
{
    public class Order
    {
        public int ID { get; set; }
        public DateTime CreateDate { get; set; }
        public decimal TotalPrice { get; set; }
        public int CustomerID { get; set; }
        public OrderStatus Status { get; set; }
    }

}
