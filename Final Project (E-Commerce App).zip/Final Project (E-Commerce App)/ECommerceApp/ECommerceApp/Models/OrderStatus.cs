﻿namespace ECommerceApp.Models
{
    public enum OrderStatus
    {
        Pending,
        Approved,
        Declined,
        Shipped,
        Delivered
    }

}
