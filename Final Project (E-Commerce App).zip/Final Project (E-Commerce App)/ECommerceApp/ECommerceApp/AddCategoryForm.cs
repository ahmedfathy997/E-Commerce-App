﻿using ECommerceApp.Models;

namespace ECommerceApp
{
    public partial class AddCategoryForm : Form
    {
        public AddCategoryForm()
        {
            InitializeComponent();
        }

        public Category NewCategory { get; set; }
    }
}
