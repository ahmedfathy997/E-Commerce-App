﻿using ECommerceApp.Models;

namespace ECommerceApp
{
    public partial class EditProductForm : Form
    {
        public EditProductForm(Models.Product selectedProduct)
        {
            InitializeComponent();
        }

        public Product UpdatedProduct { get; set; }
    }
}
