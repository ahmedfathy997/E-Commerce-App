﻿using ECommerceApp.Models;

namespace ECommerceApp
{
    public partial class AddProductForm : Form
    {
        public AddProductForm()
        {
            InitializeComponent();
        }

        public Product NewProduct { get; set; }
    }
}
