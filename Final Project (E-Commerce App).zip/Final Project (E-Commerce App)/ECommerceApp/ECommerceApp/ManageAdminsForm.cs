﻿using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class ManageAdminsForm : Form
    {
        public ManageAdminsForm(Admin? admin)
        {
            InitializeComponent();
        }
        private void btnLoad_Click(object sender, EventArgs e)
        {
            AdminRepository adminRepository = new AdminRepository(new AppDbContext());
            adminsGrdView.DataSource = adminRepository.GetAll();
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddAdminForm addAdminForm = new AddAdminForm();
            if (addAdminForm.ShowDialog() == DialogResult.OK)
            {
                Admin newAdmin = addAdminForm.NewAdmin;

                // Add the new admin to the database
                AdminRepository adminRepository = new AdminRepository(new AppDbContext());
                adminRepository.Add(newAdmin);

                // Refresh the DataGridView
                adminsGrdView.DataSource = adminRepository.GetAll();
            }
        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            // Check if an admin is selected in the DataGridView
            if (adminsGrdView.SelectedRows.Count > 0)
            {
                int selectedAdminId = (int)adminsGrdView.SelectedRows[0].Cells[0].Value;

                // Get the selected admin details
                AdminRepository adminRepository = new AdminRepository(new AppDbContext());
                Admin selectedAdmin = adminRepository.GetById(selectedAdminId);

                // Open the EditAdminForm and pass the selected admin details
                EditAdminForm editAdminForm = new EditAdminForm(selectedAdmin);
                if (editAdminForm.ShowDialog() == DialogResult.OK)
                {
                    // Update the admin details in the database
                    adminRepository.Update(editAdminForm.UpdatedAdmin);

                    // Refresh the DataGridView
                    adminsGrdView.DataSource = adminRepository.GetAll();
                }
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (adminsGrdView.SelectedRows.Count > 0)
            {
                int selectedAdminId = (int)adminsGrdView.SelectedRows[0].Cells[0].Value;

                // Delete the admin from the database
                AdminRepository adminRepository = new AdminRepository(new AppDbContext());
                adminRepository.Delete(selectedAdminId);

                // Refresh the DataGridView
                adminsGrdView.DataSource = adminRepository.GetAll();
            }
        }
    }
}