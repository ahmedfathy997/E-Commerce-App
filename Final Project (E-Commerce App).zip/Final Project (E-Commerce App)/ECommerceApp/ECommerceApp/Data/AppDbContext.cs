﻿using ECommerceApp.Models;
using Microsoft.EntityFrameworkCore;

namespace ECommerceApp.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetails> OrderDetails { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=(localdb)\\ProjectModels;Initial Catalog=ECommerceAppDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Add an admin
            modelBuilder.Entity<Admin>().HasData(new Admin
            {
                ID = 1,
                FullName = "admin",
                JobTitle = "admin",
                Email = "admin@Company.com",
                Password = "admin"
            });

            // Add a customer
            modelBuilder.Entity<Customer>().HasData(new Customer
            {
                ID = 2,
                FullName = "customer",
                Address = "home",
                Phone = "12345",
                Email = "customer@company.com",
                Password = "customer"
            });
        }
    }
}
