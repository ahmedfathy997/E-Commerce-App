using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            // Get the entered username and password
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            // Verify the entered details against the data in the database
            UserRepository userRepository = new UserRepository(new AppDbContext());
            User user = userRepository.GetByUsernameAndPassword(username, password);
            if (user != null)
            {
                // The entered details match an existing user
                if (user is Admin)
                {
                    // The user is an admin, open the admin form
                    ManageAdminsForm adminForm = new ManageAdminsForm(user as Admin);
                    this.Hide();
                    adminForm.Show();
                }
                else if (user is Customer)
                {
                    // The user is a customer, open the customer form
                    ViewProductsform customerForm = new ViewProductsform(user as Customer);
                    this.Hide();
                    customerForm.Show();
                }
            }
            else
            {
                // The entered details do not match any existing user, show an error message
                MessageBox.Show("Invalid username or password.");
            }
        }

    }
}
