﻿using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class AddCategoryForm : Form
    {
        public AddCategoryForm()
        {
            InitializeComponent();
        }

        public Category NewCategory { get; set; }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string name = txtName.Text;
                Category category = new Category();

                category.Name = name;

                CategoryRepository categoryRepository = new CategoryRepository(new AppDbContext());
                categoryRepository.Add(category);

                categoryRepository.Save(category);

                MessageBox.Show("Category added successfully.");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
        }
    }
}
