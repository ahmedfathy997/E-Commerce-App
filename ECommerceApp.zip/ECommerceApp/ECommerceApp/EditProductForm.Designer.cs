﻿namespace ECommerceApp
{
    partial class EditProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnEdit = new Button();
            txtCategoryId = new TextBox();
            txtStockQuantity = new TextBox();
            txtUnitPrice = new TextBox();
            txtNameAr = new TextBox();
            txtNameEn = new TextBox();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            SuspendLayout();
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(136, 182);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(97, 33);
            btnEdit.TabIndex = 57;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // txtCategoryId
            // 
            txtCategoryId.Location = new Point(104, 140);
            txtCategoryId.Name = "txtCategoryId";
            txtCategoryId.Size = new Size(129, 23);
            txtCategoryId.TabIndex = 56;
            // 
            // txtStockQuantity
            // 
            txtStockQuantity.Location = new Point(104, 111);
            txtStockQuantity.Name = "txtStockQuantity";
            txtStockQuantity.Size = new Size(129, 23);
            txtStockQuantity.TabIndex = 55;
            // 
            // txtUnitPrice
            // 
            txtUnitPrice.Location = new Point(104, 83);
            txtUnitPrice.Name = "txtUnitPrice";
            txtUnitPrice.Size = new Size(129, 23);
            txtUnitPrice.TabIndex = 54;
            // 
            // txtNameAr
            // 
            txtNameAr.Location = new Point(104, 53);
            txtNameAr.Name = "txtNameAr";
            txtNameAr.Size = new Size(129, 23);
            txtNameAr.TabIndex = 53;
            // 
            // txtNameEn
            // 
            txtNameEn.Location = new Point(104, 24);
            txtNameEn.Name = "txtNameEn";
            txtNameEn.Size = new Size(129, 23);
            txtNameEn.TabIndex = 52;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(16, 140);
            label9.Name = "label9";
            label9.Size = new Size(66, 15);
            label9.TabIndex = 50;
            label9.Text = "CategoryID";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(16, 111);
            label10.Name = "label10";
            label10.Size = new Size(82, 15);
            label10.TabIndex = 49;
            label10.Text = "StockQuantity";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(16, 83);
            label11.Name = "label11";
            label11.Size = new Size(58, 15);
            label11.TabIndex = 48;
            label11.Text = "Unit Price";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(16, 56);
            label12.Name = "label12";
            label12.Size = new Size(62, 15);
            label12.TabIndex = 47;
            label12.Text = "Name(AR)";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(16, 28);
            label13.Name = "label13";
            label13.Size = new Size(62, 15);
            label13.TabIndex = 46;
            label13.Text = "Name(EN)";
            // 
            // EditProductForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(282, 231);
            Controls.Add(btnEdit);
            Controls.Add(txtCategoryId);
            Controls.Add(txtStockQuantity);
            Controls.Add(txtUnitPrice);
            Controls.Add(txtNameAr);
            Controls.Add(txtNameEn);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label13);
            Name = "EditProductForm";
            Text = "Edit Product";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnEdit;
        private TextBox txtCategoryId;
        private TextBox txtStockQuantity;
        private TextBox txtUnitPrice;
        private TextBox txtNameAr;
        private TextBox txtNameEn;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
    }
}