﻿using ECommerceApp.Data;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class ViewProductsform : Form
    {
        public ViewProductsform()
        {
            InitializeComponent();
        }

        private void ViewProductsform_Load(object sender, EventArgs e)
        {
            ProductRepository productRepository = new ProductRepository(new AppDbContext());
            productsGridView.DataSource = productRepository.GetAll();
        }
    }
}
