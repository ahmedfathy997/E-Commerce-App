﻿using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class AddOrderToCartForm : Form
    {
        public Order NewOrder { get; set; }
        public AddOrderToCartForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime createdate = Convert.ToDateTime(txtCreateDate.Text);
                string totalPrice = txtPrice.Text;
                string customerId = txtcustomerID.Text;

                Order order = new Order
                {
                    CreateDate = createdate,
                    TotalPrice = Convert.ToDecimal(totalPrice),
                    CustomerID = Convert.ToInt32(customerId),
                };

                OrderRepository orderRepository = new OrderRepository(new AppDbContext());
                orderRepository.Add(order);

                // Save changes to the database
                orderRepository.Save(order);

                // Display a success message
                MessageBox.Show("Order added successfully.");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }

        }
    }
}
