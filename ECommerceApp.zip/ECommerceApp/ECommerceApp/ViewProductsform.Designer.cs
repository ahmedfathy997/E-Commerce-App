﻿namespace ECommerceApp
{
    partial class ViewProductsform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            productsGridView = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)productsGridView).BeginInit();
            SuspendLayout();
            // 
            // productsGridView
            // 
            productsGridView.AllowUserToOrderColumns = true;
            productsGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            productsGridView.Dock = DockStyle.Fill;
            productsGridView.Location = new Point(0, 0);
            productsGridView.Name = "productsGridView";
            productsGridView.Size = new Size(677, 291);
            productsGridView.TabIndex = 0;
            // 
            // ViewProductsform
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(677, 291);
            Controls.Add(productsGridView);
            Name = "ViewProductsform";
            Text = "Products";
            Load += ViewProductsform_Load;
            ((System.ComponentModel.ISupportInitialize)productsGridView).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView productsGridView;
    }
}