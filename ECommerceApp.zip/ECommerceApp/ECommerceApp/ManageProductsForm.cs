﻿using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class ManageProductsForm : Form
    {
        public ManageProductsForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Open the AddProductForm and get the new product details
            AddProductForm addProductForm = new AddProductForm();
            if (addProductForm.ShowDialog() == DialogResult.OK)
            {
                Product newProduct = addProductForm.NewProduct;

                // Add the new product to the database
                ProductRepository productRepository = new ProductRepository(new AppDbContext());
                productRepository.Add(newProduct);

                // Refresh the DataGridView
                ProductsGrdView.DataSource = productRepository.GetAll();
            }
        }
        private void btnLoad_Click(object sender, EventArgs e)
        {
            ProductRepository productRepository = new ProductRepository(new AppDbContext());
            ProductsGrdView.DataSource = productRepository.GetAll();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Check if a product is selected in the DataGridView
            if (ProductsGrdView.SelectedRows.Count > 0)
            {
                int selectedProductId = (int)ProductsGrdView.SelectedRows[0].Cells["ID"].Value;

                // Delete the product from the database
                ProductRepository productRepository = new ProductRepository(new AppDbContext());
                productRepository.Delete(selectedProductId);

                // Refresh the DataGridView
                ProductsGrdView.DataSource = productRepository.GetAll();
            }
        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            // Check if a product is selected in the DataGridView
            if (ProductsGrdView.SelectedRows.Count > 0)
            {
                int selectedProductId = (int)ProductsGrdView.SelectedRows[0].Cells["ID"].Value;

                // Get the selected product details
                ProductRepository productRepository = new ProductRepository(new AppDbContext());
                Product selectedProduct = productRepository.GetById(selectedProductId);

                // Open the EditProductForm and pass the selected product details
                EditProductForm editProductForm = new EditProductForm(selectedProduct);
                if (editProductForm.ShowDialog() == DialogResult.OK)
                {
                    // Update the product details in the database
                    productRepository.Update(editProductForm.UpdatedProduct);

                    // Refresh the DataGridView
                    ProductsGrdView.DataSource = productRepository.GetAll();
                }
            }
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminLoginManageForm adminLoginManageForm = new AdminLoginManageForm();
            adminLoginManageForm.Show();
            this.Close();

        }

    }
}