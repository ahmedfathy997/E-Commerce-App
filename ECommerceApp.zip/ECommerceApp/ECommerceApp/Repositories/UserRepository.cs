﻿using ECommerceApp.Data;
using ECommerceApp.Models;

namespace ECommerceApp.Repositories
{
    public class UserRepository
    {
        private readonly AppDbContext _context;

        public UserRepository(AppDbContext context)
        {
            _context = context;
        }
        public List<User> GetAll()
        {
            return _context.Users.ToList();
        }
        public User GetById(int id)
        {
            return _context.Users.Find(id);
        }
        public void Add(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }
        public void Update(User user)
        {
            _context.Users.Update(user);
            _context.SaveChanges();
        }
        public void Delete(int id)
        {
            var user = _context.Users.Find(id);
            _context.Users.Remove(user);
            _context.SaveChanges();
        }

        public User GetByUsernameAndPassword(string username, string password)
        {
            User user = _context.Users.FirstOrDefault(u => u.Email == username && u.Password == password);

            return user;
        }
        public void Save(Admin admin)
        {
            _context.SaveChanges();
        }
    }
}
