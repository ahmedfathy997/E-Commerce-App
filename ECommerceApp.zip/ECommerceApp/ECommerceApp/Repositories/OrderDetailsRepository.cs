﻿using ECommerceApp.Data;
using ECommerceApp.Models;

namespace ECommerceApp.Repositories
{
    public class OrderDetailsRepository
    {
        private readonly AppDbContext _context;

        public OrderDetailsRepository(AppDbContext context)
        {
            _context = context;
        }

        public List<OrderDetails> GetAll()
        {
            return _context.OrderDetails.ToList();
        }

        public OrderDetails GetById(int id)
        {
            return _context.OrderDetails.Find(id);
        }

        public void Add(OrderDetails orderDetails)
        {
            _context.OrderDetails.Add(orderDetails);
            _context.SaveChanges();
        }

        public void Update(OrderDetails orderDetails)
        {
            _context.OrderDetails.Update(orderDetails);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var orderDetails = _context.OrderDetails.Find(id);
            _context.OrderDetails.Remove(orderDetails);
            _context.SaveChanges();
        }
    }

}
