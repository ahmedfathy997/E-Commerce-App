﻿namespace ECommerceApp
{
    partial class EditCategoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnEdit = new Button();
            txtName = new TextBox();
            label13 = new Label();
            SuspendLayout();
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(223, 36);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(97, 23);
            btnEdit.TabIndex = 62;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // txtName
            // 
            txtName.Location = new Point(57, 36);
            txtName.Name = "txtName";
            txtName.Size = new Size(129, 23);
            txtName.TabIndex = 61;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(12, 39);
            label13.Name = "label13";
            label13.Size = new Size(39, 15);
            label13.TabIndex = 59;
            label13.Text = "Name";
            // 
            // EditCategoryForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(332, 79);
            Controls.Add(btnEdit);
            Controls.Add(txtName);
            Controls.Add(label13);
            Name = "EditCategoryForm";
            Text = "Edit Category";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnEdit;
        private TextBox txtName;
        private Label label13;
    }
}