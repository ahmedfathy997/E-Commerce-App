﻿using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class EditOrderForm : Form
    {
        public Order EditOrder { get; set; }
        public EditOrderForm(Order order)
        {
            InitializeComponent();
            EditOrder = order;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            decimal totalPrice = Convert.ToDecimal(txtPrice.Text);
            int customerId = Convert.ToInt32(txtcustomerID.Text);
            DateTime createDate = Convert.ToDateTime(txtCreateDate.Text);

            OrderRepository orderRepository = new OrderRepository(new AppDbContext());
            Order selectedOrder = orderRepository.GetById(EditOrder.ID);

            selectedOrder.TotalPrice = totalPrice;
            selectedOrder.CustomerID = customerId;
            selectedOrder.CreateDate = createDate;

            orderRepository.Update(selectedOrder);

            orderRepository.Save(selectedOrder);

            MessageBox.Show("Order updated successfully.");

            this.Close();

        }
    }
}
