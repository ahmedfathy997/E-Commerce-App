﻿using ECommerceApp.Models;

namespace ECommerceApp
{
    public partial class AdminLoginManageForm : Form
    {
        public Admin Admin { get; set; }
        public Order Order { get; set; }
        public AdminLoginManageForm()
        {
            InitializeComponent();
            Admin = new Admin();
            Order = new Order();
        }

        private void btnAdmins_Click(object sender, EventArgs e)
        {

            ManageAdminsForm adminForm = new ManageAdminsForm(Admin);
            this.Hide();
            adminForm.Show();
        }

        private void btnCategories_Click(object sender, EventArgs e)
        {
            ManageCategoriesForm categoryForm = new ManageCategoriesForm();
            this.Hide();
            categoryForm.Show();
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            ManageProductsForm productForm = new ManageProductsForm();
            this.Hide();
            productForm.Show();
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            ViewOrdersForm orderForm = new ViewOrdersForm(Order);
            this.Hide();
            orderForm.Show();
        }
    }
}
