﻿using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class EditAdminForm : Form
    {
        public Admin UpdatedAdmin { get; set; }
        public EditAdminForm(Admin selectedAdmin)
        {
            InitializeComponent();
            UpdatedAdmin = selectedAdmin;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            string username = txtFullName.Text;
            string password = txtPassword.Text;
            string email = txtEmail.Text;
            string jobTitle = txtJobTitle.Text;
            string isActive = txtActive.Text;

            AdminRepository adminRepository = new AdminRepository(new AppDbContext());
            Admin selectedAdmin = adminRepository.GetById((int)UpdatedAdmin.ID);

            // Update the selected admin details
            selectedAdmin.FullName = username;
            selectedAdmin.Password = password;
            selectedAdmin.Email = email;
            selectedAdmin.JobTitle = jobTitle;
            selectedAdmin.IsActive = bool.Parse(isActive);

            // Update the admin in the database
            adminRepository.Update(selectedAdmin);

            // Save changes to the database
            adminRepository.Save(selectedAdmin);

            // Display a success message
            MessageBox.Show("Admin updated successfully.");

            // Close the form
            this.Close();
        }
    }
}
