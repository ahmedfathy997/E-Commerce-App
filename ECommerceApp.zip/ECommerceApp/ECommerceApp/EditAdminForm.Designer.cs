﻿namespace ECommerceApp
{
    partial class EditAdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnEdit = new Button();
            txtJobTitle = new TextBox();
            txtActive = new TextBox();
            txtPassword = new TextBox();
            txtEmail = new TextBox();
            txtFullName = new TextBox();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            SuspendLayout();
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(167, 183);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(97, 33);
            btnEdit.TabIndex = 44;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // txtJobTitle
            // 
            txtJobTitle.Location = new Point(85, 142);
            txtJobTitle.Name = "txtJobTitle";
            txtJobTitle.Size = new Size(179, 23);
            txtJobTitle.TabIndex = 42;
            // 
            // txtActive
            // 
            txtActive.Location = new Point(85, 110);
            txtActive.Name = "txtActive";
            txtActive.Size = new Size(179, 23);
            txtActive.TabIndex = 41;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(85, 81);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(179, 23);
            txtPassword.TabIndex = 40;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(85, 52);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(179, 23);
            txtEmail.TabIndex = 39;
            // 
            // txtFullName
            // 
            txtFullName.Location = new Point(85, 23);
            txtFullName.Name = "txtFullName";
            txtFullName.Size = new Size(179, 23);
            txtFullName.TabIndex = 38;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(13, 139);
            label9.Name = "label9";
            label9.Size = new Size(50, 15);
            label9.TabIndex = 35;
            label9.Text = "Job Title";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(13, 110);
            label10.Name = "label10";
            label10.Size = new Size(40, 15);
            label10.TabIndex = 34;
            label10.Text = "Active";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(13, 82);
            label11.Name = "label11";
            label11.Size = new Size(57, 15);
            label11.TabIndex = 33;
            label11.Text = "Password";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(13, 55);
            label12.Name = "label12";
            label12.Size = new Size(36, 15);
            label12.TabIndex = 32;
            label12.Text = "Email";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(13, 27);
            label13.Name = "label13";
            label13.Size = new Size(61, 15);
            label13.TabIndex = 31;
            label13.Text = "Full Name";
            // 
            // EditAdminForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(281, 243);
            Controls.Add(btnEdit);
            Controls.Add(txtJobTitle);
            Controls.Add(txtActive);
            Controls.Add(txtPassword);
            Controls.Add(txtEmail);
            Controls.Add(txtFullName);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label13);
            Name = "EditAdminForm";
            Text = "Edit Admin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnEdit;
        private TextBox txtJobTitle;
        private TextBox txtActive;
        private TextBox txtPassword;
        private TextBox txtEmail;
        private TextBox txtFullName;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
    }
}