﻿using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class EditCategoryForm : Form
    {
        public EditCategoryForm(Category selectedCategory)
        {
            InitializeComponent();
            UpdatedCategory = selectedCategory;
        }

        public Category UpdatedCategory { get; set; }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;

            CategoryRepository categoryRepository = new CategoryRepository(new AppDbContext());
            Category selectedCategory = categoryRepository.GetById(UpdatedCategory.ID);

            selectedCategory.Name = name;

            categoryRepository.Update(selectedCategory);
            categoryRepository.Save(selectedCategory);

            MessageBox.Show("Category updated successfully.");

            this.Close();

        }
    }
}
