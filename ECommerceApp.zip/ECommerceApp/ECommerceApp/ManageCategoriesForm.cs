﻿using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class ManageCategoriesForm : Form
    {
        public ManageCategoriesForm()
        {
            InitializeComponent();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            CategoryRepository categoryRepository = new CategoryRepository(new AppDbContext());
            CategoriesGrdView.DataSource = categoryRepository.GetAll();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Open the AddCategoryForm and get the new category details
            AddCategoryForm addCategoryForm = new AddCategoryForm();
            if (addCategoryForm.ShowDialog() == DialogResult.OK)
            {
                Category newCategory = addCategoryForm.NewCategory;  // Assume NewCategory is a property in AddCategoryForm that holds the new category details

                // Add the new category to the database
                CategoryRepository categoryRepository = new CategoryRepository(new AppDbContext());
                categoryRepository.Add(newCategory);

                // Refresh the DataGridView
                CategoriesGrdView.DataSource = categoryRepository.GetAll();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            // Check if a category is selected in the DataGridView
            if (CategoriesGrdView.SelectedRows.Count > 0)
            {
                int selectedCategoryId = (int)CategoriesGrdView.SelectedRows[0].Cells["ID"].Value;

                // Get the selected category details
                CategoryRepository categoryRepository = new CategoryRepository(new AppDbContext());
                Category selectedCategory = categoryRepository.GetById(selectedCategoryId);

                // Open the EditCategoryForm and pass the selected category details
                EditCategoryForm editCategoryForm = new EditCategoryForm(selectedCategory);
                if (editCategoryForm.ShowDialog() == DialogResult.OK)
                {
                    // Update the category details in the database
                    categoryRepository.Update(editCategoryForm.UpdatedCategory);  // Assume UpdatedCategory is a property in EditCategoryForm that holds the updated category details

                    // Refresh the DataGridView
                    CategoriesGrdView.DataSource = categoryRepository.GetAll();
                }
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Check if a category is selected in the DataGridView
            if (CategoriesGrdView.SelectedRows.Count > 0)
            {
                int selectedCategoryId = (int)CategoriesGrdView.SelectedRows[0].Cells[0].Value;

                // Delete the category from the database
                CategoryRepository categoryRepository = new CategoryRepository(new AppDbContext());
                categoryRepository.Delete(selectedCategoryId);

                // Refresh the DataGridView
                CategoriesGrdView.DataSource = categoryRepository.GetAll();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminLoginManageForm adminLoginManageForm = new AdminLoginManageForm();
            adminLoginManageForm.Show();
            this.Close();
        }

    }
}
