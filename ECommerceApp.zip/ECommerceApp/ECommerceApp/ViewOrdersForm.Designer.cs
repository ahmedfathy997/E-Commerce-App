﻿namespace ECommerceApp
{
    partial class ViewOrdersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ordersGridView = new DataGridView();
            btnStatus = new Button();
            btnBack = new Button();
            ((System.ComponentModel.ISupportInitialize)ordersGridView).BeginInit();
            SuspendLayout();
            // 
            // ordersGridView
            // 
            ordersGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            ordersGridView.Location = new Point(0, 0);
            ordersGridView.Name = "ordersGridView";
            ordersGridView.Size = new Size(799, 345);
            ordersGridView.TabIndex = 0;
            // 
            // btnStatus
            // 
            btnStatus.Location = new Point(12, 368);
            btnStatus.Name = "btnStatus";
            btnStatus.Size = new Size(140, 44);
            btnStatus.TabIndex = 1;
            btnStatus.Text = "Status";
            btnStatus.UseVisualStyleBackColor = true;
            btnStatus.Click += btnStatus_Click;
            // 
            // btnBack
            // 
            btnBack.Location = new Point(620, 368);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(117, 44);
            btnBack.TabIndex = 2;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // ViewOrdersForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnBack);
            Controls.Add(btnStatus);
            Controls.Add(ordersGridView);
            Name = "ViewOrdersForm";
            Text = "ViewOrdersForm";
            Load += ViewOrdersForm_Load;
            ((System.ComponentModel.ISupportInitialize)ordersGridView).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView ordersGridView;
        private Button btnStatus;
        private Button btnBack;
    }
}