﻿using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class EditProductForm : Form
    {
        public EditProductForm(Product selectedProduct)
        {
            InitializeComponent();
            UpdatedProduct = selectedProduct;
        }

        public Product UpdatedProduct { get; set; }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            string nameEn = txtNameEn.Text;
            string nameAr = txtNameAr.Text;
            Decimal unitPrice = Convert.ToDecimal(txtUnitPrice.Text);
            int quantity = Convert.ToInt32(txtStockQuantity.Text);
            int categoryID = Convert.ToInt32(txtCategoryId.Text);

            ProductRepository productRepository = new ProductRepository(new Data.AppDbContext());
            Product selectedProdcut = productRepository.GetById(UpdatedProduct.ID);

            selectedProdcut.NameEn = nameEn;
            selectedProdcut.NameAr = nameAr;
            selectedProdcut.UnitPrice = unitPrice;
            selectedProdcut.StockQuantity = quantity;
            selectedProdcut.CategoryID = categoryID;


            productRepository.Update(selectedProdcut);
            productRepository.Save(selectedProdcut);

            MessageBox.Show("Category updated successfully.");
            this.Close();

        }
    }
}
