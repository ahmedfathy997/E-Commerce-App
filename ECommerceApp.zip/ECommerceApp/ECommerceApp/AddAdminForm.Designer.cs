﻿namespace ECommerceApp
{
    partial class AddAdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtJobTitle = new TextBox();
            txtPassword = new TextBox();
            txtEmail = new TextBox();
            txtFullName = new TextBox();
            label9 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            btnAdd = new Button();
            label1 = new Label();
            txtIsActive = new TextBox();
            SuspendLayout();
            // 
            // txtJobTitle
            // 
            txtJobTitle.Location = new Point(86, 119);
            txtJobTitle.Name = "txtJobTitle";
            txtJobTitle.Size = new Size(215, 23);
            txtJobTitle.TabIndex = 27;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(86, 90);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(215, 23);
            txtPassword.TabIndex = 25;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(86, 61);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(215, 23);
            txtEmail.TabIndex = 24;
            // 
            // txtFullName
            // 
            txtFullName.Location = new Point(86, 32);
            txtFullName.Name = "txtFullName";
            txtFullName.Size = new Size(215, 23);
            txtFullName.TabIndex = 23;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(14, 119);
            label9.Name = "label9";
            label9.Size = new Size(50, 15);
            label9.TabIndex = 20;
            label9.Text = "Job Title";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(14, 91);
            label11.Name = "label11";
            label11.Size = new Size(57, 15);
            label11.TabIndex = 18;
            label11.Text = "Password";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(14, 64);
            label12.Name = "label12";
            label12.Size = new Size(36, 15);
            label12.TabIndex = 17;
            label12.Text = "Email";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(14, 36);
            label13.Name = "label13";
            label13.Size = new Size(61, 15);
            label13.TabIndex = 16;
            label13.Text = "Full Name";
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(204, 193);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(97, 33);
            btnAdd.TabIndex = 29;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(14, 148);
            label1.Name = "label1";
            label1.Size = new Size(40, 15);
            label1.TabIndex = 30;
            label1.Text = "Active";
            // 
            // txtIsActive
            // 
            txtIsActive.Location = new Point(86, 148);
            txtIsActive.Name = "txtIsActive";
            txtIsActive.Size = new Size(215, 23);
            txtIsActive.TabIndex = 31;
            // 
            // AddAdminForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(318, 230);
            Controls.Add(txtIsActive);
            Controls.Add(label1);
            Controls.Add(btnAdd);
            Controls.Add(txtJobTitle);
            Controls.Add(txtPassword);
            Controls.Add(txtEmail);
            Controls.Add(txtFullName);
            Controls.Add(label9);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label13);
            Name = "AddAdminForm";
            Text = "Add Admin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtJobTitle;
        private TextBox txtPassword;
        private TextBox txtEmail;
        private TextBox txtFullName;
        private Label label9;
        private Label label11;
        private Label label12;
        private Label label13;
        private Button btnAdd;
        private Label label1;
        private TextBox txtIsActive;
    }
}