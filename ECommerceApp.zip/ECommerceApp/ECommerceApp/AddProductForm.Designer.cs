﻿namespace ECommerceApp
{
    partial class AddProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAdd = new Button();
            txtCategoryId = new TextBox();
            txtStockQuantity = new TextBox();
            txtUnitPrice = new TextBox();
            txtNameAr = new TextBox();
            txtNameEn = new TextBox();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            SuspendLayout();
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(129, 188);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(97, 33);
            btnAdd.TabIndex = 44;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // txtCategoryId
            // 
            txtCategoryId.Location = new Point(97, 135);
            txtCategoryId.Name = "txtCategoryId";
            txtCategoryId.Size = new Size(173, 23);
            txtCategoryId.TabIndex = 42;
            // 
            // txtStockQuantity
            // 
            txtStockQuantity.Location = new Point(97, 106);
            txtStockQuantity.Name = "txtStockQuantity";
            txtStockQuantity.Size = new Size(173, 23);
            txtStockQuantity.TabIndex = 41;
            // 
            // txtUnitPrice
            // 
            txtUnitPrice.Location = new Point(97, 78);
            txtUnitPrice.Name = "txtUnitPrice";
            txtUnitPrice.Size = new Size(173, 23);
            txtUnitPrice.TabIndex = 40;
            // 
            // txtNameAr
            // 
            txtNameAr.Location = new Point(97, 48);
            txtNameAr.Name = "txtNameAr";
            txtNameAr.Size = new Size(173, 23);
            txtNameAr.TabIndex = 39;
            // 
            // txtNameEn
            // 
            txtNameEn.Location = new Point(97, 19);
            txtNameEn.Name = "txtNameEn";
            txtNameEn.Size = new Size(173, 23);
            txtNameEn.TabIndex = 38;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(9, 135);
            label9.Name = "label9";
            label9.Size = new Size(66, 15);
            label9.TabIndex = 35;
            label9.Text = "CategoryID";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(9, 106);
            label10.Name = "label10";
            label10.Size = new Size(82, 15);
            label10.TabIndex = 34;
            label10.Text = "StockQuantity";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(9, 78);
            label11.Name = "label11";
            label11.Size = new Size(58, 15);
            label11.TabIndex = 33;
            label11.Text = "Unit Price";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(9, 51);
            label12.Name = "label12";
            label12.Size = new Size(62, 15);
            label12.TabIndex = 32;
            label12.Text = "Name(AR)";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(9, 23);
            label13.Name = "label13";
            label13.Size = new Size(62, 15);
            label13.TabIndex = 31;
            label13.Text = "Name(EN)";
            // 
            // AddProductForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(283, 232);
            Controls.Add(btnAdd);
            Controls.Add(txtCategoryId);
            Controls.Add(txtStockQuantity);
            Controls.Add(txtUnitPrice);
            Controls.Add(txtNameAr);
            Controls.Add(txtNameEn);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label13);
            Name = "AddProductForm";
            Text = "Add Product";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAdd;
        private TextBox txtCategoryId;
        private TextBox txtStockQuantity;
        private TextBox txtUnitPrice;
        private TextBox txtNameAr;
        private TextBox txtNameEn;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
    }
}