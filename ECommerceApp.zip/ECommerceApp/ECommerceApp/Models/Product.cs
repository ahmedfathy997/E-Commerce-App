﻿namespace ECommerceApp.Models
{
    public class Product
    {
        public int ID { get; set; }
        public string NameEn { get; set; }
        public string NameAr { get; set; }
        public decimal UnitPrice { get; set; }
        public int StockQuantity { get; set; }
        public int CategoryID { get; set; }
    }

}
