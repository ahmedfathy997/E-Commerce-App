﻿namespace ECommerceApp.Models
{
    public class Admin : User
    {
        public string JobTitle { get; set; }
        public DateTime? HireDate { get; set; }
    }
}