﻿namespace ECommerceApp
{
    partial class AdminLoginManageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAdmins = new Button();
            btnCategories = new Button();
            btnProducts = new Button();
            btnOrders = new Button();
            SuspendLayout();
            // 
            // btnAdmins
            // 
            btnAdmins.Location = new Point(21, 102);
            btnAdmins.Name = "btnAdmins";
            btnAdmins.Size = new Size(86, 37);
            btnAdmins.TabIndex = 0;
            btnAdmins.Text = "Admins";
            btnAdmins.UseVisualStyleBackColor = true;
            btnAdmins.Click += btnAdmins_Click;
            // 
            // btnCategories
            // 
            btnCategories.Location = new Point(124, 102);
            btnCategories.Name = "btnCategories";
            btnCategories.Size = new Size(93, 37);
            btnCategories.TabIndex = 1;
            btnCategories.Text = "Categories";
            btnCategories.UseVisualStyleBackColor = true;
            btnCategories.Click += btnCategories_Click;
            // 
            // btnProducts
            // 
            btnProducts.Location = new Point(234, 102);
            btnProducts.Name = "btnProducts";
            btnProducts.Size = new Size(93, 38);
            btnProducts.TabIndex = 2;
            btnProducts.Text = "Products";
            btnProducts.UseVisualStyleBackColor = true;
            btnProducts.Click += btnProducts_Click;
            // 
            // btnOrders
            // 
            btnOrders.Location = new Point(348, 102);
            btnOrders.Name = "btnOrders";
            btnOrders.Size = new Size(96, 37);
            btnOrders.TabIndex = 3;
            btnOrders.Text = "Orders";
            btnOrders.UseVisualStyleBackColor = true;
            btnOrders.Click += btnOrders_Click;
            // 
            // AdminLoginManageForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(472, 226);
            Controls.Add(btnOrders);
            Controls.Add(btnProducts);
            Controls.Add(btnCategories);
            Controls.Add(btnAdmins);
            Name = "AdminLoginManageForm";
            Text = "Manager";
            ResumeLayout(false);
        }

        #endregion

        private Button btnAdmins;
        private Button btnCategories;
        private Button btnProducts;
        private Button btnOrders;
    }
}