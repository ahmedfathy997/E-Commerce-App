﻿namespace ECommerceApp
{
    partial class ManageCategoriesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnLoad = new Button();
            btnDelete = new Button();
            btnEdit = new Button();
            btnAdd = new Button();
            CategoriesGrdView = new DataGridView();
            btnBack = new Button();
            ((System.ComponentModel.ISupportInitialize)CategoriesGrdView).BeginInit();
            SuspendLayout();
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(361, 411);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(93, 33);
            btnLoad.TabIndex = 9;
            btnLoad.Text = "Load";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(247, 411);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(89, 33);
            btnDelete.TabIndex = 8;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(128, 411);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(97, 33);
            btnEdit.TabIndex = 7;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(13, 411);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(95, 33);
            btnAdd.TabIndex = 6;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // CategoriesGrdView
            // 
            CategoriesGrdView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            CategoriesGrdView.Location = new Point(1, 6);
            CategoriesGrdView.Name = "CategoriesGrdView";
            CategoriesGrdView.Size = new Size(799, 358);
            CategoriesGrdView.TabIndex = 5;
            // 
            // btnBack
            // 
            btnBack.Location = new Point(681, 411);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(89, 33);
            btnBack.TabIndex = 10;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // ManageCategoriesForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnBack);
            Controls.Add(btnLoad);
            Controls.Add(btnDelete);
            Controls.Add(btnEdit);
            Controls.Add(btnAdd);
            Controls.Add(CategoriesGrdView);
            Name = "ManageCategoriesForm";
            Text = "Manage Categories";
            ((System.ComponentModel.ISupportInitialize)CategoriesGrdView).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button btnLoad;
        private Button btnDelete;
        private Button btnEdit;
        private Button btnAdd;
        private DataGridView CategoriesGrdView;
        private Button btnBack;
    }
}