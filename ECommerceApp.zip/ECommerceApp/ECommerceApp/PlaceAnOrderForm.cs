﻿using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class PlaceAnOrderForm : Form
    {
        public PlaceAnOrderForm()
        {
            InitializeComponent();
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                AddOrderToCartForm addOrderForm = new AddOrderToCartForm();
                if (addOrderForm.ShowDialog() == DialogResult.OK)
                {
                    Order newOrder = addOrderForm.NewOrder;

                    OrderRepository orderRepository = new OrderRepository(new AppDbContext());
                    orderRepository.Add(newOrder);

                    // Refresh the DataGridView
                    OrderGrdView.DataSource = orderRepository.GetAll();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (OrderGrdView.SelectedRows.Count > 0)
                {
                    int selectedOrderId = (int)OrderGrdView.SelectedRows[0].Cells["ID"].Value;

                    OrderRepository orderRepository = new OrderRepository(new AppDbContext());
                    Order selectedOrder = orderRepository.GetById(selectedOrderId);

                    EditOrderForm editOrderForm = new EditOrderForm(selectedOrder);
                    if (editOrderForm.ShowDialog() == DialogResult.OK)
                    {
                        orderRepository.Update(editOrderForm.EditOrder);
                        // Refresh the DataGridView
                        OrderGrdView.DataSource = orderRepository.GetAll();
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (OrderGrdView.SelectedRows.Count > 0)
            {
                int selectedAdminId = (int)OrderGrdView.SelectedRows[0].Cells["ID"].Value;

                // Delete the admin from the database
                OrderRepository orderRepository = new OrderRepository(new AppDbContext());
                orderRepository.Delete(selectedAdminId);

                // Refresh the DataGridView
                OrderGrdView.DataSource = orderRepository.GetAll();
            }

        }

        private void PlaceAnOrderForm_Load(object sender, EventArgs e)
        {
            OrderRepository orderRepository = new OrderRepository(new AppDbContext());
            var orders = orderRepository.GetAll();
            OrderGrdView.DataSource = orders;
        }
    }
}
