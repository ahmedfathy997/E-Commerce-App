﻿namespace ECommerceApp
{
    partial class CustomerLoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnProducts = new Button();
            btnOrder = new Button();
            SuspendLayout();
            // 
            // btnProducts
            // 
            btnProducts.Location = new Point(64, 77);
            btnProducts.Name = "btnProducts";
            btnProducts.Size = new Size(86, 30);
            btnProducts.TabIndex = 0;
            btnProducts.Text = "Products";
            btnProducts.UseVisualStyleBackColor = true;
            btnProducts.Click += btnProducts_Click;
            // 
            // btnOrder
            // 
            btnOrder.Location = new Point(180, 77);
            btnOrder.Name = "btnOrder";
            btnOrder.Size = new Size(85, 30);
            btnOrder.TabIndex = 1;
            btnOrder.Text = "Order";
            btnOrder.UseVisualStyleBackColor = true;
            btnOrder.Click += btnOrder_Click;
            // 
            // CustomerLoginForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(343, 157);
            Controls.Add(btnOrder);
            Controls.Add(btnProducts);
            Name = "CustomerLoginForm";
            Text = "Products";
            ResumeLayout(false);
        }

        #endregion

        private Button btnProducts;
        private Button btnOrder;
    }
}