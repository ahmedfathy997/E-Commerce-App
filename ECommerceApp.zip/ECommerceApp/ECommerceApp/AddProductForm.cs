﻿using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class AddProductForm : Form
    {
        public AddProductForm()
        {
            InitializeComponent();
        }

        public Product NewProduct { get; set; }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string nameEn = txtNameEn.Text;
            string nameAr = txtNameAr.Text;
            Decimal unitPrice = Convert.ToDecimal(txtUnitPrice.Text);
            int quantity = Convert.ToInt32(txtStockQuantity.Text);
            int categoryID = Convert.ToInt32(txtCategoryId.Text);

            Product product = new Product();

            product.NameEn = nameEn;
            product.NameAr = nameAr;
            product.UnitPrice = unitPrice;
            product.StockQuantity = quantity;
            product.CategoryID = categoryID;

            ProductRepository productRepository = new ProductRepository(new AppDbContext());
            productRepository.Add(product);
            productRepository.Save(product);

            MessageBox.Show("Category added successfully.");
            this.Close();
        }
    }
}
