﻿namespace ECommerceApp
{
    partial class AddOrderToCartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            label3 = new Label();
            txtcustomerID = new TextBox();
            txtPrice = new TextBox();
            label1 = new Label();
            txtCreateDate = new TextBox();
            btnAdd = new Button();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(13, 27);
            label2.Name = "label2";
            label2.Size = new Size(61, 15);
            label2.TabIndex = 1;
            label2.Text = "Total Price";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(13, 60);
            label3.Name = "label3";
            label3.Size = new Size(73, 15);
            label3.TabIndex = 2;
            label3.Text = "Customer ID";
            // 
            // txtcustomerID
            // 
            txtcustomerID.Location = new Point(92, 57);
            txtcustomerID.Name = "txtcustomerID";
            txtcustomerID.Size = new Size(148, 23);
            txtcustomerID.TabIndex = 4;
            // 
            // txtPrice
            // 
            txtPrice.Location = new Point(92, 24);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(148, 23);
            txtPrice.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(13, 89);
            label1.Name = "label1";
            label1.Size = new Size(31, 15);
            label1.TabIndex = 6;
            label1.Text = "Date";
            // 
            // txtCreateDate
            // 
            txtCreateDate.Location = new Point(92, 86);
            txtCreateDate.Name = "txtCreateDate";
            txtCreateDate.Size = new Size(148, 23);
            txtCreateDate.TabIndex = 7;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(165, 134);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 36);
            btnAdd.TabIndex = 9;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // AddOrderToCartForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(255, 175);
            Controls.Add(btnAdd);
            Controls.Add(txtCreateDate);
            Controls.Add(label1);
            Controls.Add(txtPrice);
            Controls.Add(txtcustomerID);
            Controls.Add(label3);
            Controls.Add(label2);
            Name = "AddOrderToCartForm";
            Text = "AddOrderToCartForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label2;
        private Label label3;
        private TextBox txtcustomerID;
        private TextBox txtPrice;
        private Label label1;
        private TextBox txtCreateDate;
        private Button btnAdd;
    }
}