﻿using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class UpdateOrderStatusForm : Form
    {
        public UpdateOrderStatusForm(Order selectedOrder)
        {
            InitializeComponent();
            UpdatedOrder = selectedOrder;
        }
        public Order UpdatedOrder { get; set; }
        private void txtStatus_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            int status = Convert.ToInt32(txtStatus.Text);

            OrderRepository orderRepository = new OrderRepository(new AppDbContext());
            Order selectedOrder = orderRepository.GetById((int)UpdatedOrder.ID);

            selectedOrder.Status = (OrderStatus)status;

            orderRepository.Update(selectedOrder);

            orderRepository.Save(selectedOrder);

            MessageBox.Show("Status updated successfully.");

            // Close the form
            this.Close();
        }
    }
}
