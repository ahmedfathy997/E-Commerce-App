﻿namespace ECommerceApp
{
    public partial class CustomerLoginForm : Form
    {
        public CustomerLoginForm()
        {
            InitializeComponent();
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            ViewProductsform viewProductsform = new ViewProductsform();
            this.Hide();
            viewProductsform.Show();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            PlaceAnOrderForm placeAnOrderForm = new PlaceAnOrderForm();
            this.Hide();
            placeAnOrderForm.Show();
        }
    }
}
