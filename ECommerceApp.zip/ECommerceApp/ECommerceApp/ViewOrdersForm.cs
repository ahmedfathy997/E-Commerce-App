﻿using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class ViewOrdersForm : Form
    {
        public ViewOrdersForm(Order? order)
        {
            InitializeComponent();
        }
        private void ViewOrdersForm_Load(object sender, EventArgs e)
        {
            OrderRepository orderRepository = new OrderRepository(new AppDbContext());
            ordersGridView.DataSource = orderRepository.GetAll();
        }

        private void OrderRepository_OrderPlaced(object source, EventArgs e)
        {
            // Refresh the DataGridView
            OrderRepository orderRepository = new OrderRepository(new AppDbContext());
            ordersGridView.DataSource = orderRepository.GetAll();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminLoginManageForm adminLoginManageForm = new AdminLoginManageForm();
            adminLoginManageForm.Show();
            this.Close();

        }

        private void btnStatus_Click(object sender, EventArgs e)
        {
            try
            {
                if (ordersGridView.SelectedRows.Count > 0)
                {
                    int selectedOrderId = (int)ordersGridView.SelectedRows[0].Cells["ID"].Value;

                    OrderRepository orderRepository = new OrderRepository(new AppDbContext());
                    Order selectedOrder = orderRepository.GetById(selectedOrderId);

                    UpdateOrderStatusForm editStatusForm = new UpdateOrderStatusForm(selectedOrder);
                    if (editStatusForm.ShowDialog() == DialogResult.OK)
                    {
                        orderRepository.Update(editStatusForm.UpdatedOrder);
                        // Refresh the DataGridView
                        ordersGridView.DataSource = orderRepository.GetAll();
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

    }
}
