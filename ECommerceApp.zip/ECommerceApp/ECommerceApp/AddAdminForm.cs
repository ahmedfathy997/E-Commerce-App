﻿using ECommerceApp.Data;
using ECommerceApp.Models;
using ECommerceApp.Repositories;

namespace ECommerceApp
{
    public partial class AddAdminForm : Form
    {
        public Admin NewAdmin { get; set; }
        public AddAdminForm()
        {
            InitializeComponent();
        }
        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            try
            {
                // Get the entered username and password
                string username = txtFullName.Text;
                string password = txtPassword.Text;
                string email = txtEmail.Text;
                string jobTitle = txtJobTitle.Text;
                string isActive = txtIsActive.Text;

                // Create a new admin
                Admin admin = new Admin
                {
                    FullName = username,
                    Password = password,
                    Email = email,
                    JobTitle = jobTitle,
                    IsActive = Convert.ToBoolean(isActive)
                };

                // Add the new admin to the database
                UserRepository userRepository = new UserRepository(new AppDbContext());
                userRepository.Add(admin);

                // Save changes to the database
                userRepository.Save(admin);

                // Clear the input fields
                txtFullName.Clear();
                txtPassword.Clear();
                txtEmail.Clear();
                txtJobTitle.Clear();

                // Display a success message
                MessageBox.Show("Admin added successfully.");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
        }
    }
}
