﻿namespace ECommerceApp
{
    partial class AddCategoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAdd = new Button();
            txtName = new TextBox();
            label13 = new Label();
            btnBack = new Button();
            SuspendLayout();
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(230, 19);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(97, 33);
            btnAdd.TabIndex = 57;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // txtName
            // 
            txtName.Location = new Point(66, 25);
            txtName.Name = "txtName";
            txtName.Size = new Size(129, 23);
            txtName.TabIndex = 52;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(12, 28);
            label13.Name = "label13";
            label13.Size = new Size(39, 15);
            label13.TabIndex = 46;
            label13.Text = "Name";
            // 
            // btnBack
            // 
            btnBack.Location = new Point(230, 60);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(97, 33);
            btnBack.TabIndex = 58;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            // 
            // AddCategoryForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(339, 105);
            Controls.Add(btnBack);
            Controls.Add(btnAdd);
            Controls.Add(txtName);
            Controls.Add(label13);
            Name = "AddCategoryForm";
            Text = "Add Category";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAdd;
        private TextBox txtName;
        private Label label13;
        private Button btnBack;
    }
}